document.addEventListener('DOMContentLoaded', function() {
    console.log('JavaScript Loaded');
    // Add more interactive JS features as needed
});

